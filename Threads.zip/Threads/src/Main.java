public class Main {

	public static void main(String[] args) {
 	   
//        double[] list = new double[1<<22];    
//        System.out.println(list.length);
//        for (int i=0; i<list.length; i++)
//                list[i] = Math.random();
//        long startTime = System.nanoTime();                              
//        double[] bigs = bigNums(list);   
//        long endTime = System.nanoTime();
//        System.out.println("Running time = " + 
//            ((endTime-startTime)/1000));                          
//        System.out.println(bigs.length);
		double[] list = new double[8];
		double[] bigs = bigNums(list);

}
// definition of big nums is that its bigger than average of numbers in the list 
	private static double[] bigNums(double[] list) {
		
		MyThread1 t1 = new MyThread1(list,0,4);	
		MyThread2 t2 = new MyThread2(list,5,8);	

	    t1.start();	
		t2.start();
		t1.getBigNo();
		t2.getBigNo();
		return null;
	}

}