
public class MyThread2 extends Thread {
	double[] list;
	int forAvg;
	int start;
	int end;
	double avg;
	

	public MyThread2(double[] list, int start, int end) {
		this.list = list;
		this.start = start;
		this.end= end;
	}

	@Override
	public void run() {
		forAvg = start;
		for (int i = (start+1); i <= end; i++) {
			forAvg = forAvg + i;
		}
		//System.out.println(forAvg);
		avg = (forAvg/4);
		System.out.println("Avarage from 2nd thread is " + avg);
	}

	public void getBigNo() {
		 System.out.println("The numbers greter then AVARAGE from thread 2 are: ");

		for (int i = start; i <= end; i++) {
			if(i > avg) {
				 System.out.println(i);
			}		
		}
		
		
		
	}
	
}
