
public class MyThread1 extends Thread {
	double[] list;
	int forAvg;
	int start;
	int end;
	double avg;
	

	public MyThread1(double[] list, int start, int end) {
		this.list = list;
		this.start = start;
		this.end= end;
	}

	@Override
	public void run() {
		forAvg = start;
		for (int i = start; i <= end; i++) {

			forAvg = forAvg + i;
		}
		//System.out.println(forAvg);
		avg = (forAvg/end);
		System.out.println("Avarage from 1nd thread is " + avg);
	}

	public void getBigNo() {
		 System.out.println("The numbers greter then AVARAGE from thread 1 are :");

		for (int i = start; i <= end; i++) {
			if(i > avg) {
				 System.out.println(i);
			}
			
				
		}
		
		
		
	}
	
}
