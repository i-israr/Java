package model;

public class Item {
private String name;
private int qty;
private double price;
private double total;

public Item(String name, int itemQuantity, double price2, double total2) {
	super();
	this.name = name;
	this.qty = itemQuantity;
	this.price = price2;
	this.total = total2;
}

public String getName() {
	return name;
}

public void setName(String name) {
	this.name = name;
}

public int getQty() {
	return qty;
}

public void setQty(int qty) {
	this.qty = qty;
}

public double getPrice() {
	return price;
}

public void setPrice(double price) {
	this.price = price;
}

public double getTotal() {
	return total;
}

public void setTotal(double total) {
	this.total = total;
}
}
