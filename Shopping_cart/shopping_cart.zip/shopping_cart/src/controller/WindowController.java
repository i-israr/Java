package controller;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.ContextMenu;
import javafx.scene.control.MenuButton;
import javafx.scene.control.MenuItem;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import model.Item;

public class WindowController {
	String itemTitle;
    @FXML
    private ComboBox<String> comboItmName;
    ObservableList<String> fruitList = FXCollections.observableArrayList("Apple","Banana","Cherry","Mango","Orange","Pomegranate");
    @FXML
    private TextField itemQty;
	
    @FXML
    private TableView<Item> item;

    @FXML
    private TableColumn<Item, String> itmName;

    @FXML
    private TableColumn<Item, String> itmQty;

    @FXML
    private TableColumn<Item, String> itmPrice;

    @FXML
    private TableColumn<Item, String> itmTotal;
    private ObservableList<Item> itemList = FXCollections.observableArrayList();

    @FXML
    private Button addItm;
    
    public void initialize(){
    	comboItmName.setValue("Mango");
    	comboItmName.setItems(fruitList);
	
		System.out.println("Initilized!!!");
		itmName.setCellValueFactory(new PropertyValueFactory<Item, String>("name"));
		itmQty.setCellValueFactory(new PropertyValueFactory<Item, String>("qty"));
		itmPrice.setCellValueFactory(new PropertyValueFactory<Item, String>("price"));
		itmTotal.setCellValueFactory(new PropertyValueFactory<Item, String>("total"));
	}
    
    @FXML
    void add_Itms(ActionEvent event) {
	    	
	    	double price, total;
	    	int itemQuantity = Integer.parseInt(itemQty.getText());
	    	
	    	if(comboItmName.getValue()== "Apple")
	    	{
	    		price = 150.0;
	    		total = price*itemQuantity;
	    		
	    		itemList.add(new Item("Apple",itemQuantity,price,total));
	    		item.setItems(itemList);	
	    	}
	    	if(comboItmName.getValue()== "Mango")
	    	{
	    		price = 120.0;
	    		total = price*itemQuantity;
	    		
	    		itemList.add(new Item("Mango",itemQuantity,price,total));
	    		item.setItems(itemList);
	    	}
	    	if(comboItmName.getValue()== "Pomegranate")
	    	{
	    		price = 200.0;
	    		total = price*itemQuantity;
	    		
	    		itemList.add(new Item("Pomegranate",itemQuantity,price,total));
	    		item.setItems(itemList);	
	    	}
	    	if(comboItmName.getValue()== "Cherry")
	    	{
	    		price = 350.0;
	    		total = price*itemQuantity;
	    		
	    		itemList.add(new Item("Cherry",itemQuantity,price,total));
	    		item.setItems(itemList);	
	    	}
	    	if(comboItmName.getValue()== "Banana")
	    	{
	    		price = 100.0;
	    		total = price*itemQuantity;
	    		
	    		itemList.add(new Item("Banana",itemQuantity,price,total));
	    		item.setItems(itemList);		
	    	}
	    	if(comboItmName.getValue()== "Orange")
	    	{
	    		price = 80.0;
	    		total = price*itemQuantity;
	    		
	    		itemList.add(new Item("Orange",itemQuantity,price,total));
	    		item.setItems(itemList);	
	    	}
	    
    }
}
