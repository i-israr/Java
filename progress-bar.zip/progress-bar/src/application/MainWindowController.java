package application;

import java.net.URL;
import java.util.ResourceBundle;

import javafx.concurrent.Task;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;
import javafx.scene.control.ProgressBar;
import javafx.scene.control.ProgressIndicator;
import javafx.scene.control.TextField;

public class MainWindowController{

	@FXML ProgressBar bar;
	@FXML ProgressIndicator indicator;
	@FXML Label status;

	public class DoWork extends Task<Integer>{

		@Override
		protected Integer call() throws Exception {
			System.out.println("from call "+Thread.currentThread().getName());
			for(int i=0;i<10;i++){
				System.out.println(i+1);
				updateProgress(i+1, 10);
				Thread.sleep(500);
				if(isCancelled()){
					return i;
				}
			}

			return 10;
		}

		@Override
		public boolean cancel(boolean mayInterruptIfRunning) {
			updateMessage("Cancelled");
			return super.cancel(mayInterruptIfRunning);
		}

		@Override
		protected void updateProgress(double workDone, double max) {
			updateMessage("Progress "+workDone);
			super.updateProgress(workDone, max);
		}

	}



	 public void initialize(){
		DoWork task = new DoWork();

		bar.progressProperty().bind(task.progressProperty());
		indicator.progressProperty().bind(task.progressProperty());
		status.textProperty().bind(task.messageProperty());

		new Thread(task).start();

	}




}
