public class Main {

	public static void main(String[] args) {
		System.out.println(Thread.currentThread().getName());
		
		System.out.println(Runtime.getRuntime().availableProcessors());
		// thread creation methods
		// 1 - extending the thread class
		// 2- implementing the runnnable 
		MyThread t1 = new MyThread();
		MyThread t2 = new MyThread();
		
		t1.start();// async
		t2.start();// async
		
		
		// 1               2                  3
		// calc            calc               wait
		// calc            calc				wait
		// complete        complete         wait
		// complete        complete         print both totals
		// complete        completed        completed
		
		
		try {
			Thread.sleep(1000*20);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		System.out.println("T1's count"+t1.getCount());
		System.out.println("T2's count"+t2.getCount());
		
		System.out.println("Main exiting");
	}

}