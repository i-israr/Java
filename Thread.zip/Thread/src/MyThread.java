public class MyThread extends Thread {
private int count;

	@Override
	public void run() {
	System.out.println(Thread.currentThread().getName());
	
	for (int i = 0; i < 10; i++) {
	System.out.println("Printing from "+Thread.currentThread().getName()+" "+i);
	count+=i;
	try {
		Thread.sleep(1000);
	} catch (InterruptedException e) {
		e.printStackTrace();
	}
	System.out.println(Thread.currentThread().getName()+"I'll continue printing again.....");
	}
	
	
	
	
	System.out.println("Last line before finishing thread"+Thread.currentThread().getName());
	}

	public int getCount() {
		return count;
	}
	
	

}