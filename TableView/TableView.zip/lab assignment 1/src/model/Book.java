package model;

public class Book {
	private String author;
	private String title;
	private String publisher;
	private String serialNo;
	public Book(String author, String title, String publisher, String serialNo) {
		super();
		this.author = author;
		this.title = title;
		this.publisher = publisher;
		this.serialNo = serialNo;
	}
	public String getAuthor() {
		return author;
	}
	public void setAuthor(String author) {
		this.author = author;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getPublisher() {
		return publisher;
	}
	public void setPublisher(String publisher) {
		this.publisher = publisher;
	}
	public String getSerialNo() {
		return serialNo;
	}
	public void setSerialNo(String serialNo) {
		this.serialNo = serialNo;
	}

	


}
