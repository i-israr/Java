package controller;



import java.util.ArrayList;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import model.Book;;

public class MainWindowController {
	Main main;
	Stage primaryStage;
	private ObservableList<Book> bookList  = FXCollections.observableArrayList();

	//views
	@FXML TableView<Book> tableView;
//	@FXML TableColumn<Person,String> titleColumn;
//	@FXML TableColumn<Person,String> authorColumn;
//
//	@FXML TableColumn<Person,String> publisherColumn;
	@FXML TableColumn<Book,String> SNColumn;
	@FXML TableColumn<Book,String> BTColumn;
	@FXML TableColumn<Book,String> authorColumn;
	@FXML TableColumn<Book,String> publisher;
	

	
	
	public void setMain(Main main, Stage primaryStage) {
		System.out.println("Chala"+main);
		System.out.println("primary"+primaryStage);
		this.main = main;
		this.primaryStage = primaryStage;
		setTableData();
		System.out.println("Person List:"+bookList );
		tableView.setItems(bookList );
	}


	private void setTableData() {

		bookList.add(new Book("Israr","IlamKiDonya","Khan","112211"));
		//personList.add(new Person("Taimoor","Ahmed","35","2424243"));
		//personList.add(new Person("Ehsan","Ahmed","45","345353"));

	}


	public void initialize(){
		System.out.println("Initilized!!!");
		SNColumn.setCellValueFactory(new PropertyValueFactory<Book, String>("serialNo"));
		BTColumn.setCellValueFactory(new PropertyValueFactory<Book, String>("title"));
		authorColumn.setCellValueFactory(new PropertyValueFactory<Book, String>("author"));	
		publisher.setCellValueFactory(new PropertyValueFactory<Book, String>("publisher"));
	}

	public void closeButtonClick(){
		
		System.out.println("Close button Called");
	}
    @FXML
    public void enterdata(ActionEvent event) {
    	main.secondWindow();
    	System.out.println("Enter new button Call");
    }
	public void addBookToTable(Book newBook) {
		bookList.add(newBook);
	}


}
