package controller;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import model.Book;

public class SecondWindowController {
	Main main;
	Stage primaryStage;
	MainWindowController mainWindowController;
    @FXML
    private Button submit;

//    @FXML
//    private Button reset1;

    @FXML
    private TextField bookName;

    @FXML
    private TextField authorName;

    @FXML
    private TextField publisher1;

    @FXML
    private TextField seriialNo;
    @FXML
	   public void submit(ActionEvent event) {	
		String title = bookName.getText();
		String author = authorName.getText();
		String publisher = publisher1.getText();
		String isbn = seriialNo.getText();
		Book newBook = new Book(author,title,publisher,isbn);
		mainWindowController.addBookToTable(newBook);

	    }

    public void setMain(Main main,Stage primaryStage) {
				this.main = main;
		this.primaryStage = primaryStage;
	}

	public void setMainWindowController(MainWindowController mainWindowController) {
	 this.mainWindowController = mainWindowController;
		
	}
	


}

