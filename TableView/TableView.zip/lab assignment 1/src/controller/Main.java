package controller;

import java.awt.SecondaryLoop;
import java.io.IOException;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.layout.AnchorPane;



public class Main extends Application {
		Stage primaryStage;
		Stage secondStage;
		MainWindowController mainWindowController ;

	@Override
	public void start(Stage primaryStage) {
		this.primaryStage = primaryStage;

		mainWindow();
	}

	private void mainWindow() {

		this.secondStage=new Stage();
		try {
			FXMLLoader loader = new FXMLLoader(Main.class.getResource("/view/MainWindowView.fxml"));
			AnchorPane pane = loader.load();
			mainWindowController = loader.getController();
			mainWindowController.setMain(this,primaryStage);
			Scene scene = new Scene(pane);
			secondStage.setScene(scene);
			secondStage.show();
			secondStage.setTitle("Israr ul haq");
			secondStage.show();
			

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
	public void secondWindow() {
	
		try{
			FXMLLoader loader= new FXMLLoader(Main.class.getResource("/view/SecondWindow.fxml"));
			AnchorPane pane = loader.load();
			SecondWindowController controller = loader.getController();
			controller.setMain(this, primaryStage);
			controller.setMainWindowController(mainWindowController);
			Scene scene = new Scene(pane);
			primaryStage.setScene(scene);
			primaryStage.show();
			primaryStage.setTitle("Enter new Data");
			primaryStage.show();

		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	


	public static void main(String[] args) {
		launch(args);
	}
}
