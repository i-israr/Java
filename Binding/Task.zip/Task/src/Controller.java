

import javafx.application.Platform;
import javafx.beans.Observable;
import javafx.beans.binding.Bindings;
import javafx.beans.property.SimpleBooleanProperty;
import javafx.beans.property.SimpleDoubleProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.geometry.Pos;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TableCell;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TablePosition;
import javafx.scene.control.TableView;
import javafx.scene.control.TableColumn.CellDataFeatures;
import javafx.scene.control.TableColumn.CellEditEvent;
import javafx.scene.control.cell.CheckBoxTableCell;
import javafx.scene.control.cell.ComboBoxTableCell;
import javafx.util.Callback;
import javafx.util.converter.NumberStringConverter;



public class Controller {

    @FXML
    private TableView<Data> tableView;

    @FXML
    private TableColumn<Data, Number> HeatEnergy;

    @FXML
    private TableColumn<Data, Number> massColumn;

    @FXML
    private TableColumn<Data, Number> durationColumn;

    @FXML
    private TableColumn<Data, Number> totalColumn;

    ObservableList<Data> list;
    
    @FXML
    private Label lblTotal;

    @FXML
    private Label lblValue;
    
    private ObservableList<Data> cart;
    SimpleDoubleProperty MUL;
    SimpleDoubleProperty totalColumnProp;
    
    //SimpleDoubleProperty totalColumnProp;
    //SimpleDoubleProperty calc;
    
	ObservableList<Number> options = FXCollections.observableArrayList(
            10,
            20,
            50
            );
    
    
    public void initialize() {
        // Editable
        tableView.setEditable(true);//UNVISIBALE CUMBOBOX
    	tableView.setItems(setTableData());
    	//cart= tableView.getItems();
    	setHeatEnergy();
    	setmassColumn();
    	setDurationColumn();
    	setTotalColumn();
    
    	setCalcTotal();
    	

    }

    private void setCalcTotal() {
    	double total =0.0;
		
    	for(Data d:list) {
    		total += d.getTotal();
    	}
    	
    	SimpleStringProperty calc = new SimpleStringProperty(String.valueOf(total));
        lblValue.textProperty().bind(calc);
      System.out.println(list);
      System.out.println(total);
		
	}
    
   

	private void setTotalColumn() {
    	totalColumn.setCellValueFactory(new Callback<CellDataFeatures<Data, Number>, ObservableValue<Number>>() {
  		  
            @Override
            public ObservableValue<Number> call(CellDataFeatures<Data, Number> param) {
                Data d = param.getValue();
 
                totalColumnProp = new SimpleDoubleProperty(d.getHeatEnergy()/(d.getMass()*d.getDuration()));
                
               // totalColumnProp = new SimpleDoubleProperty(d.getHeatEnergy());
                // Note: singleCol.setOnEditCommit(): Not work for
                // CheckBoxTableCell.
 
                // When "Single?" column change.
                
//                feeColumnProp.addListener(new ChangeListener<Number>() {
// 
//                    @Override
//                    public void changed(ObservableValue<? extends Number> observable, Number oldValue,
//                    		Number newValue) {
//                        //d.setSingle(newValue);// content changign due to this line
//                    }
//                });
//                SimpleStringProperty calc = new SimpleStringProperty(String.valueOf(totalColumnProp));
//                r1.textProperty().bind(calc);
                return totalColumnProp;
            }
        });
		
	}

	private void setDurationColumn() {
    	//durationColumn.setEditable(true);
    	durationColumn.setCellValueFactory(new Callback<CellDataFeatures<Data, Number>, ObservableValue<Number>>() {
  		  
            @Override
            public ObservableValue<Number> call(CellDataFeatures<Data, Number> param) {
                Data d = param.getValue();
 
                SimpleIntegerProperty durationColumnProp = new SimpleIntegerProperty(d.getDuration());
 
                // Note: singleCol.setOnEditCommit(): Not work for
                // CheckBoxTableCell.
 
                // When "Single?" column change.
                
                durationColumnProp.addListener(new ChangeListener<Number>() {
 
                    @Override
                    public void changed(ObservableValue<? extends Number> observable, Number oldValue,
                    		Number newValue) {
                        //d.setSingle(newValue);// content changign due to this line
                    }
                });
                return durationColumnProp;
            }
        });
		
    	durationColumn.setCellFactory(ComboBoxTableCell.forTableColumn(options));
//    	durationColumn.setCellFactory(new Callback<TableColumn<Data, String>,TableCell<Data, String>>() {
//            @Override
//            public TableCell<Data, String> call(TableColumn<Data, String> p) {
//            	ComboBoxTableCell<Data, String> cell = new ComboBoxTableCell<Data, String>();
//                //ComboBoxTableCell<S, T>
//                cell.setAlignment(Pos.CENTER);
//                return cell;
//            }
//        });
    	
    	durationColumn.setOnEditCommit((CellEditEvent<Data, Number> event) -> {
             TablePosition<Data, Number> pos = event.getTablePosition();
  
             Number duration = event.getNewValue();
             //System.out.println("Number duration"+duration);
             int row = pos.getRow();
             //System.out.println("printing row"+row);
             //Data d = event.getTableView().getItems().get(row);
             Data d = tableView.getItems().get(row);
             
             
             
             
             System.out.println(d.getMass()*duration.intValue());
            // d.setTotal(d.getFee()*duration.intValue());// saved in model
             d.setDuration(duration.intValue());
             //totalColumnProp.setValue(d.getFee()*duration.intValue());
             setCalcTotal();
             tableView.requestFocus();
             tableView.getSelectionModel().select(row);
             tableView.getFocusModel().focus(row);
             refresh();
             //this is the line
           //  SimpleDoubleProperty calc = new SimpleDoubleProperty(d.getFee()*duration.intValue());
           //  SimpleStringProperty aVal = new SimpleStringProperty(""); 
           //  Bindings.bindBidirectional(aVal, calc, new NumberStringConverter());
            // lblValue.textProperty().bind(aVal);
             //Person person = event.getTableView().getItems().get(row);
  
             //person.setGender(newGender.getCode());
         });
  
	}

	private void setmassColumn() {
		massColumn.setCellValueFactory(new Callback<CellDataFeatures<Data, Number>, ObservableValue<Number>>() {  
            @Override
            public ObservableValue<Number> call(CellDataFeatures<Data, Number> param) {
                Data d = param.getValue();
 
                SimpleDoubleProperty massColumnProp = new SimpleDoubleProperty(d.getMass());               
                massColumnProp.addListener(new ChangeListener<Number>() {
 
                    @Override
                    public void changed(ObservableValue<? extends Number> observable, Number oldValue,
                    		Number newValue) {
                        //d.setSingle(newValue);// content changign due to this line
                    }
                });
                return massColumnProp;
            }
        });
		
	}

	private void setHeatEnergy() {
		HeatEnergy.setCellValueFactory(new Callback<CellDataFeatures<Data, Number>, ObservableValue<Number>>() {  
            @Override
            public ObservableValue<Number> call(CellDataFeatures<Data, Number> param) {
                Data d = param.getValue();
 
                SimpleIntegerProperty hE = new SimpleIntegerProperty(d.getHeatEnergy());               
                hE.addListener(new ChangeListener<Number>() {
 
                    @Override
                    public void changed(ObservableValue<? extends Number> observable, Number oldValue,
                    		Number newValue) {
                        //d.setSingle(newValue);// content changign due to this line
                    }
                });
                return hE;
            }
        });
		
	}

	private ObservableList<Data> setTableData() {
    	
    	list = FXCollections.observableArrayList();
    	
		Data d1 = new Data(2000, 15, 3);
		Data d2 = new Data(5022, 20,2);
		Data d3 = new Data(2600, 10,4);
		Data d4 = new Data(3200, 25,1);
		list.addAll(d1,d2,d3,d4);
		return list;  
		
	}
	
	void refresh() {
		System.out.println("hi");
		tableView.getColumns().get(3).setVisible(false);
		tableView.getColumns().get(3).setVisible(true);
	}
	void refreshTable() {
		//aList = makeCopy();
		tableView.getItems().clear();
		System.out.println(list);
		tableView.getItems().addAll(list);
		
//		setPackageColumn();
//    	setFeeColumn();
//    	setDurationColumn();
//    	setTotalColumn();
//    	setCalcTotal();
		
//	    final ObservableList<Data> items = tableView.getItems();
//	    if( items == null || items.size() == 0) return;
//
//	    final Data item = tableView.getItems().get(0);
//	    items.remove(0);
//	    Platform.runLater(new Runnable(){
//	        @Override
//	        public void run() {
//	            items.add(0, item);
//	        }
//	    });
	 }

}

