import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.control.ComboBox;

public class Data {
	//private int id;
    //this is not a observal                                          //tableview
	private int HeatEnergy;//--------->so we convert this into a property(observel)
	private double mass;
	private int duration;
	private double total;
	
	
	public Data(int packAge, double mass, int duration) {
		super();
		this.HeatEnergy = packAge;
		this.mass = mass;
		this.duration = duration;
	}

	public void setHeatEnergy(int heatEnergy) {
		HeatEnergy = heatEnergy;
	}

	public int getHeatEnergy() {
		return HeatEnergy;
	}




	public int getPackAge() {
		return HeatEnergy;
	}


	public void setPackAge(int packAge) {
		this.HeatEnergy = packAge;
	}


	public double getMass() {
		return mass;
	}


	public void setMass(double mass) {
		this.mass = mass;
	}


//	public ComboBox getDuration() {
//		return duration;
//	}
//
//
//	public void setDuration(ComboBox duration) {
//		this.duration = duration;
//	}

   // computed column
	public double getTotal() {
		//return fee*duration;
		double res; 
		res=mass*duration;
		return HeatEnergy/res;
	}


//	public void setTotal(double total) {
//		this.total = total;
//	}


	public int getDuration() {
		return duration;
	}


	public void setDuration(int duration) {
		this.duration = duration;
	}


	@Override
	public String toString() {
		return "[ total=" + getTotal() + "] [ duration="+duration+"]";
	}





//	public String getDuration() {
//		return duration;
//	}
//
//
//	public void setDuration(String duration) {
//		this.duration = duration;
//	}



	
	
	
	
	 
	

}
