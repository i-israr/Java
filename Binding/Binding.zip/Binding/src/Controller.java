import java.net.URL;
import java.util.ResourceBundle;

import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;

public class Controller implements Initializable
 {
	private final StringProperty textValue = new SimpleStringProperty();

	public String getTextValue() {

	return textValue.get();
	}
	public StringProperty textValueProperty()
	{

	return textValue;

	}

	public void setTextValue(String textValue)

	{

	this.textValue.set(textValue);

	}

    @FXML
    private TextField txt;

    @FXML
    private Label lbl;

	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
	    lbl.textProperty().bind(txt.textProperty());
		
	}


}
