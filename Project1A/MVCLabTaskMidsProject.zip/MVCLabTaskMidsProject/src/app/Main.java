package app;

import java.io.IOException;

import controller.MainWindowController;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.FlowPane;
import javafx.stage.Stage;

public class Main extends Application {
Stage primaryStage;
	@Override
	public void start(Stage primaryStage) throws Exception {
		// TODO Auto-generated method stub
		this.primaryStage = primaryStage;
		mainWindow();
		
	}

	public void mainWindow() {
		FXMLLoader loader = new FXMLLoader(Main.class.getResource("/view/MainWindowView.fxml"));
		//MainWindowController controller = loader.getController();
		AnchorPane pane;
		try {
			loader = new FXMLLoader(Main.class.getResource("/view/MainWindowView.fxml"));
			pane = loader.load();
			MainWindowController controller = loader.getController();
			controller.setNew(this);
			Scene scene = new Scene(pane);
			// put the scene on the stage
			primaryStage.setScene(scene);
			primaryStage.show();
			primaryStage.setTitle("Israr ul haq");
			primaryStage.show();
			//controller.setMain(this);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		launch(args);
	}

}
