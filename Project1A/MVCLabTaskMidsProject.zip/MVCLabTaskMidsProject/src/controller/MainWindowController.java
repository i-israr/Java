package controller;

import java.text.NumberFormat;
import java.util.Locale;

import app.Main;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.Label;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleGroup;
import javafx.scene.input.MouseEvent;

public class MainWindowController {
	int percent, result;
	int shiptotal,endresult;
	int price1, quantity1;
	int check=0;
	Main main;
    @FXML
    private TextField item;

    @FXML
    private TextField price;
    
    @FXML
    private TextField quantity;

    @FXML
    private CheckBox tex;

    @FXML
    private RadioButton nD;

    @FXML
    private ToggleGroup shippingGroup;

    @FXML
    private RadioButton tW;

    @FXML
    private RadioButton sD;

    @FXML
    private Label total;

    @FXML
    private Button process;

    @FXML
    private Button reset;

    @FXML
    void process(ActionEvent event) {
    
		price1 = Integer.parseInt(price.getText());
    	//System.out.println(price1);
    	
    	quantity1 = Integer.parseInt(quantity.getText());
    	//System.out.println(quantity1);
    	
    	result = price1*quantity1;
    	if(check == 1) {
    		percent = (result*7)/100;
        	//System.out.println(percent);
    	}
    	endresult = result+percent+shiptotal;
    	//System.out.println("Total Due "+ endresult);
    	//total = new Label(Integer.toString(totalInT));
    	
    	double priceInUSD = endresult; 
    	NumberFormat currencyFormat = NumberFormat.getCurrencyInstance(Locale.US);
    	//System.out.printf("Total Due " +currencyFormat.format(priceInUSD));
    	total.setText(currencyFormat.format(priceInUSD));
    	
    	
    }
    @FXML
    void foo(MouseEvent event) {
    	//System.out.println("Toggled: " + shippingGroup.getSelectedToggle().getUserData().toString());
		String ship =shippingGroup.getSelectedToggle().getUserData().toString();
		shiptotal = Integer.parseInt(ship);


    	
    }
    @FXML
    void boo(MouseEvent event) {
		check = 1;
		}
    @FXML
    void reset(ActionEvent event) {
    	//System.out.println("reset");
    	main.mainWindow();
    }
  
	public void setNew(Main main2) {
		// TODO Auto-generated method stub
		this.main = main2;
	}

}
