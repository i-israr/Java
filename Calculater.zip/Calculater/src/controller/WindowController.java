package controller;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.text.Text;

public class WindowController {
	int a1,b1,ans,a2,b2,ans2,a3,b3,ans3;
    @FXML
    private TextField t1;

    @FXML
    private Text result1;
    
    @FXML
    private Button Add;

    @FXML
    private TextField t2;
    
    @FXML
    private TextField t3;

    @FXML
    private Button Sub;

    @FXML
    private TextField t4;

    @FXML
    private Text result2;

    @FXML
    private TextField t5;

    @FXML
    private Button mul;

    @FXML
    private TextField t6;

    @FXML
    private Text result3;

    @FXML
    private Text result;

    @FXML
    void add(ActionEvent event) {
    	a1 = Integer.parseInt(t1.getText());
    	b1 = Integer.parseInt( t2.getText());
    	ans = a1 + b1;
    	String pas = Integer.toString(ans); 
    	result1.setText(pas);
    }
    @FXML
    void mul(ActionEvent event) {
    	a3 = Integer.parseInt(t5.getText());
    	b3 = Integer.parseInt( t6.getText());
    	ans3 = a3 * b3;
    	String pas = Integer.toString(ans3); 
    	result3.setText(pas);
    	String end = Integer.toString(ans+ans2+ans3); 
    	result.setText(end);
    			}

    @FXML
    void sub(ActionEvent event) {
    	a2 = Integer.parseInt(t3.getText());
    	b2 = Integer.parseInt( t4.getText());
    	ans2 = a2 - b2;
    	String pas = Integer.toString(ans2); 
    	result2.setText(pas);
    }

}
