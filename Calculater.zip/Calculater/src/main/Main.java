package main;



import java.io.IOException;

import controller.WindowController;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.FlowPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class Main extends Application{
	Stage primaryStage;
@Override
public void start(Stage primaryStage) throws Exception {
	this.primaryStage = primaryStage;
	
mainWindow();

	
}
	private void mainWindow() {
		try {
			FXMLLoader loader = new FXMLLoader(Main.class.getResource("/view/WindowView.fxml"));
			//WindowController windowcontroller = loader.getController();	
			VBox pane;
			pane= loader.load();
			Scene scene = new Scene(pane);
			//put the scene on the stage
			primaryStage.setScene(scene);
			primaryStage.show();
			primaryStage.setTitle("Israr ul haq");
			primaryStage.show();
		}
		catch (IOException e) {
			e.printStackTrace();
		}
}	
	public static void main(String[] args) {
		launch(args);
		

	}

}
