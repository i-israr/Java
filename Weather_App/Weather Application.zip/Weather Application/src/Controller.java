import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URL;
import java.net.URLConnection;
import java.util.HashMap;
import java.util.Map;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import javafx.concurrent.ScheduledService;
import javafx.concurrent.Task;
import javafx.concurrent.WorkerStateEvent;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.scene.control.TextField;
import javafx.scene.image.ImageView;
import javafx.scene.text.Text;
import javafx.util.Duration;

public class Controller  {

    @FXML
    private TextField txttFeld;

    @FXML
    private Text temp;

    @FXML
    private Text hum;

    @FXML
    private Text pre;

    public Text getTemp() {
		return temp;
	}
	public void setTemp(Text temp) {
		this.temp = temp;
	}
	@FXML
    private Text min;
    @FXML
    private Text max;
    @FXML
    private ImageView img;

	private static Map<String, Object> jsonToMap(String str) {
		Map<String, Object>map = new Gson().fromJson(
				str,new TypeToken<HashMap<String,Object>>() {}.getType()
				);
		
		return map;
	}
   @FXML
    void txtAction(ActionEvent event)  {
    	String cName = txttFeld.getText();
    	
    	
    	String API_KEY = "3427ffbbb55413ca1248cc9adde94b6e";
		String LOCATION = cName;
		//String urlString = "http://api.openweathermap.org/data/2.5/weather?q="+LOCATION+"&appid="+API_KEY+"&units=imperial";
		String urlString = "http://api.openweathermap.org/data/2.5/weather?q="+LOCATION+"&appid="+API_KEY+"&units=metric";
		
		TimerService service = new TimerService();
		service.setPeriod(Duration.seconds(5));
		service.setOnSucceeded(new EventHandler<WorkerStateEvent>() {
	    @Override
		public void handle(WorkerStateEvent t) {
		
		
		try {	
			StringBuilder result = new StringBuilder();
			URL url = new URL(urlString);
			URLConnection conn = url.openConnection();
			BufferedReader rd = new BufferedReader(new InputStreamReader(conn.getInputStream()));
			String line;
			
			while((line = rd.readLine())!= null) {
				result.append(line);
			}
			rd.close();
      		System.out.println(result);
			
			Map<String, Object> respMap = jsonToMap(result.toString());
			Map<String, Object> mainMap = jsonToMap(respMap.get("main").toString());
			//Map<String, Object> windMap = jsonToMap(respMap.get("wind").toString());
			
			System.out.println("Current Temperature:"+mainMap.get("temp"));
			System.out.println("Current Humidity:"+mainMap.get("humidity"));
			System.out.println("Current Speeds:"+mainMap.get("speed"));
			System.out.println("Current Angle:"+mainMap.get("deg"));
			//PollingService a = new PollingService(temp,hum,pre,min,max);
			temp.setText("" + mainMap.get("temp"));
			//img.setImage("/mypic.jpg");

			hum.setText("" + mainMap.get("humidity"));
			pre.setText("" + mainMap.get("pressure"));
			min.setText("" + mainMap.get("temp_min"));
			max.setText("" + mainMap.get("temp_max"));
		}catch (IOException e) {
			System.out.println("hi");
			System.out.println(e.getMessage());
		}
    }
    });
	service.start();
    
    
    }
}
    class TimerService extends ScheduledService<String> {

        public TimerService() {
    	}

        protected String getCount() {
    		return null;
    	}

        protected Task<String> createTask() {
            return new Task<String>() {
                protected String call() {
                    return getCount();
                }
            };
        }
    }