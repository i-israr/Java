import java.io.IOException;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
public class Main extends Application{
	Stage primaryStage;
@Override
public void start(Stage primaryStage) throws Exception {
	this.primaryStage = primaryStage;
mainWindow();	
}
	private void mainWindow() {
		try {
			FXMLLoader loader = new FXMLLoader(Main.class.getResource("GUI.fxml"));	
			AnchorPane pane;
			pane= loader.load();
			Scene scene = new Scene(pane);
			//put the scene on the stages
			primaryStage.setScene(scene);
			primaryStage.setTitle("Weather app");
			primaryStage.show();
		}
		catch (IOException e) {
			e.printStackTrace();
		}
}	
	public static void main(String[] args) {	
		launch(args);
	}

}
