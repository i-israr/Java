package lambdaEventHandler;

public interface myInterface {
public void foo();
}
