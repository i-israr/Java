package lambdaEventHandler;

import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.FlowPane;
import javafx.stage.Stage;

public class Main extends Application implements EventHandler<ActionEvent>{
public static void main(String[] args) {
	launch(args);
}
@Override
public void start(Stage window)
{ window.setTitle("Lambda Handler");
FlowPane root= new FlowPane();
Button button=new Button("Btn1");
root.getChildren().add(button);
button.setOnAction(this);
Scene scene =new Scene (root,400,400);
window.setScene(scene);
window.show();
	}
@Override
public void handle(ActionEvent event) {
	myInterface a=()->System.out.println("FOO");
	a.foo();
}
}
