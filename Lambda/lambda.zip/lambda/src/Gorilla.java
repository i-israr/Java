
public interface Gorilla {
		String move(); 
		
}
