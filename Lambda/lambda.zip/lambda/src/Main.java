import java.util.Arrays;
import java.util.List;

//public class Main {
//
//	public static void main(String[] args) {
//		// TODO Auto-generated method stub
//		List<Integer> integers = Arrays.asList(1,2,3,4,5);
//		integers.forEach((x)-> System.out.println(x+1));
//				
//	}
//
//}

class GorillaFamily {
	String walk = "walk";
	void everyonePlay(boolean baby){
		//String approach = "amble"; 
	
		//approach = "run";
		play(() -> walk);
		//play(() -> baby ? "hitch a ride": "run"); 
		//play(() -> approach);
	}
	void play(Gorilla g) { 
		System.out.println(g.move());
	} 
	public static void main(String[] args) {
	}
}

