package lambda;

public interface myInterface {

}
